# WeLoveMovies Frontend Application

This is the Front End Application for the WeLoveMovies project. Follow the instructions below.

## Installation

1. Fork / clone this repository.
1. Run `npm install`.

Use `npm start` to run the application. If you deploy this application, create a `.env.production` file similar to the `.env.development` file.
