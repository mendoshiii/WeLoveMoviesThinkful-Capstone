if (process.env.USER) require("dotenv").config();
const express = require("express");
const app = express();

module.exports = app;
